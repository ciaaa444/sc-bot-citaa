process.env.TZ = 'Asia/Jakarta'

const axios = require('axios')
const sharp = require('sharp')
const moment = require('moment-timezone')

let arrayMenu = [
  'all', 'ai', 'main', 'downloader', 'database', 'rpg', 'rpgG', 'sticker', 
  'advanced', 'xp', 'fun', 'game', 'github', 'group', 'image', 'nsfw', 
  'info', 'internet', 'islam', 'kerang', 'maker', 'news', 'owner', 'voice', 
  'quotes', 'store', 'stalk', 'shortlink', 'tools', 'anonymous'
]

const allTags = {
  all: 'SEMUA MENU',
  ai: 'AI',
  main: 'UTAMA',
  downloader: 'DOWNLOADER',
  database: 'DATABASE',
  rpg: 'RPG',
  rpgG: 'RPG GUILD',
  sticker: 'STICKER',
  advanced: 'ADVANCED',
  xp: 'XP & LEVEL',
  fun: 'FUN',
  game: 'GAME',
  github: 'GITHUB',
  group: 'GROUP',
  image: 'IMAGE',
  nsfw: 'NSFW',
  info: 'INFO',
  internet: 'INTERNET',
  islam: 'ISLAM',
  kerang: 'KERANG AJAIB',
  maker: 'MAKER',
  news: 'NEWS',
  owner: 'OWNER',
  voice: 'VOICE',
  quotes: 'QUOTES',
  store: 'STORE',
  stalk: 'STALK',
  shortlink: 'SHORTLINK',
  tools: 'TOOLS',
  anonymous: 'ANONYMOUS'
}

const THUMB_URL = 'https://files.catbox.moe/4cjq9o.jpg'
let cachedThumb = null

async function getThumbnail() {
  if (cachedThumb) return cachedThumb
  try {
    const res = await axios.get(THUMB_URL, {
      responseType: 'arraybuffer',
      timeout: 10000
    })
  
    cachedThumb = await sharp(Buffer.from(res.data))
      .resize(300, 300, { fit: 'cover' })
      .jpeg({ quality: 85 })
      .toBuffer()
  } catch (e) {
    cachedThumb = null
  }
  return cachedThumb
}

let handler = async (m, { conn, usedPrefix, args }) => {
  try {
    let user = global.db.data.users[m.sender] || {}
    let level = user.level || 0
    let limit = user.limit || 0
    let name = m.pushName || 'User'
    let input = (args[0] || '').toLowerCase()

    let now = moment().tz('Asia/Jakarta')
    let tanggal = now.format('DD/MM/YYYY')
    let jam = now.format('HH:mm:ss')
    let uptime = clockString(process.uptime() * 1000)

    let thumb = await getThumbnail()

    let plugins = Object.values(global.plugins)
      .filter(v => v.help && !v.disabled)
      .map(v => {
        return {
          help: Array.isArray(v.help) ? v.help : [v.help],
          tags: Array.isArray(v.tags) ? v.tags : [v.tags],
          premium: v.premium,
          limit: v.limit,
          customPrefix: v.customPrefix
        }
      })

    let ucapan = 'Selamat ' + (jam >= '18:00:00' ? 'Malam' : jam >= '15:00:00' ? 'Sore' : jam >= '11:00:00' ? 'Siang' : jam >= '04:00:00' ? 'Pagi' : 'Dini Hari')

    // =========================
    // MENU UTAMA (DAFTAR KATEGORI)
    // =========================
    if (!input) {
      let categoryText = ''
      for (let tag of arrayMenu) {
        if (tag === 'all') continue
        categoryText += `│ᩮ⃘᧑ ${usedPrefix}menu ${tag}\n`
      }

      let text = `
ʜᴀʟᴏ ᴋᴀᴋ 👋 ꜱᴀyᴀ ᴀᴅᴀʟᴀʜ ʙᴏᴛ ᴡʜᴀᴛꜱᴀᴩᴩ ᴏᴛᴏᴍᴀᴛɪꜱ yᴀɴɢ ᴅᴀᴩᴀᴛ ᴍᴇᴍʙᴀɴᴛᴜ ᴍᴇʟᴀᴋᴜᴋᴀɴ ꜱᴇꜱᴜᴀᴛᴜ, ᴍᴇɴᴄᴀʀɪ ᴅᴀɴ ᴍᴇɴᴅᴀᴩᴀᴛᴋᴀɴ ᴅᴀᴛᴀ ᴀᴛᴀᴜ ɪɴꜰᴏʀᴍᴀꜱɪ ᴍᴇʟᴀʟᴜɪ ᴡʜᴀᴛꜱᴀᴩᴩ.
      
╭────「 *INFO BOT* 」
├➵ ԋαι ƙαƙ ${name}
├➵ 𝐩𝐫𝐞𝐟𝐢𝐱 : ${usedPrefix}
├➵ 𝐥𝐞𝐯𝐞𝐥 : ${level}
├➵ 𝐥𝐢𝐦𝐢𝐭 : ${limit}
╰─────────────✦
├➵ 𝖽𝖺𝗍𝖾 : ${tanggal}
├➵ 𝗍𝗂𝗆𝖾 : ${jam} WIB
├➵ 𝗋𝗎𝗇𝗍𝗂𝗆𝖾 : ${uptime}
╰─────────────✦
├〔 𝖆𝖑𝖑 𝖒𝖊𝖓𝖚 〕
${categoryText}│
├─〔 𝖎𝖓𝖋𝖔 〕
├➵ ƙҽƚιƙ ${usedPrefix}ɱҽɳυ αʅʅ 
├➵ υɳƚυƙ ɱҽʅιԋαƚ ʂҽɱυα ɱҽɳυ
╰─────────────✦`.trim()

      return conn.sendMessage(m.chat, {
        document: Buffer.alloc(0), 
        mimetype: 'application/pdf',
        fileName: '🦋 𝗏𝗂𝗍𝖺 𝗆𝗎𝗅𝗍𝗂 𝖽𝖾𝗏𝗂𝖼𝖾', 
        fileLength: 2026100000000, 
        pageCount: 2026, 
        caption: text,
        jpegThumbnail: thumb,
        contextInfo: {
          mentionedJid: [m.sender]
        }
      }, { quoted: m })
    }

    // =========================
    // MENU TIDAK ADA
    // =========================
    if (!allTags[input]) {
      return m.reply(`Menu *${input}* tidak ditemukan.\n\nKetik *${usedPrefix}menu* untuk melihat daftar menu.`)
    }

    // =========================
    // RENDER CATEGORY LIST
    // =========================
    const renderCategory = (tag) => {
      let cmds = plugins.filter(v => v.tags.includes(tag))
      let txt = `╭━━━⊹ 𓊆 ${allTags[tag]} 𓊇`

      if (cmds.length < 1) {
        txt += `\n│ᩮ⃘᧑ Tidak ada menu`
      } else {
        for (let cmd of cmds) {
          for (let h of cmd.help) {
            let isPremium = cmd.premium ? ' Ⓟ' : ''
            let isLimit = cmd.limit ? ' Ⓛ' : ''
            txt += `\n│ᩮ⃘᧑ ${cmd.customPrefix ? '' : usedPrefix}${h}${isLimit}${isPremium}`
          }
        }
      }
      txt += `\n╰━━━━━━━━━━━━⊹` // Suku penutup nempel rapat di sini biar ga bug menggantung
      return txt
    }

    // =========================
    // MENU ALL / CATEGORY RENDERER
    // =========================
    let result = `
╭─── 𓊈 𝖛𝖎𝖙𝖆𝖆 - 𝖎𝖒𝖚𝖙 𓊉
││ᩮ⃘᧑ 𝘂𝘀𝗲𝗿 : ${name}
││ᩮ⃘᧑ 𝗹𝗲𝘃𝗲𝗹 : ${level}
││ᩮ⃘᧑ 𝗹𝗶𝗺𝗶𝘁 : ${limit}
││ᩮ⃘᧑ 𝘁𝗶𝗺𝗲 : ${jam} 𝗪𝗜𝗕
╰╯`.trim()

    if (input === 'all') {
      for (let tag of arrayMenu) {
        if (tag === 'all') continue
        result += '\n\n' + renderCategory(tag)
      }
    } else {
      result += '\n\n' + renderCategory(input)
    }

    result += `\n\n> Ⓛ = memakai limit\n> Ⓟ = premium only`

    return conn.sendMessage(m.chat, {
      document: Buffer.alloc(0),
      mimetype: 'application/pdf',
      fileName: `🌸 𝖺𝗅𝗅 𝗆𝖾𝗇𝗎`,
      fileLength: 50000000000, 
      pageCount: 100,
      caption: result,
      jpegThumbnail: thumb,
      contextInfo: {
        mentionedJid: [m.sender]
      }
    }, { quoted: m })

  } catch (e) {
    console.log(e)
    m.reply('Menu mengalami error, coba lagi nanti.')
  }
}

handler.help = ['menu', 'help']
handler.tags = ['main']
handler.command = /^(menu|help)$/i

module.exports = handler

function clockString(ms) {
  if (isNaN(ms)) return '--:--:--'
  let h = Math.floor(ms / 3600000)
  let m = Math.floor(ms / 60000) % 60
  let s = Math.floor(ms / 1000) % 60
  
  return [
    h.toString().padStart(2, '0') + 'hari',
    m.toString().padStart(2, '0') + 'jam',
    s.toString().padStart(2, '0') + 'menit'
  ].join(' : ')
}