let handler = async (m, { conn }) => {
  let text = `Thanks Too :
- NOVI
- RAIDEN-MD
- NILOU
- <PACAR GW PARK JONGGUN>
`

  conn.sendMessage(m.chat, {
    image: { url: 'https://files.catbox.moe/j2ibeg.jpg' },
    caption: text
  }, { quoted: m })
}

handler.help = ['tqto', 'team']
handler.tags = ['info']
handler.command = /^(tqto|team)$/i

module.exports = handler
