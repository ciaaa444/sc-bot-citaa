let handler = async (m, { conn }) => {
    let totalf = Object.values(global.plugins).filter(v => v.help && v.tags).length
    let totalPlugins = Object.keys(global.plugins).length

    let txt = `
🍃  › 𝘁𝗼𝘁𝗮𝗹 𝗳𝗶𝘁𝘂𝗿𝗿
╭╮
││⸙ 𝗉𝗅𝗎𝗀𝗂𝗇 𝗅𝗈𝖺𝖽𝖾𝖽 : ${totalPlugins}
││⸙ 𝗍𝗈𝗍𝖺𝗅 𝖿𝗂𝗍𝗎𝗋 : ${totalf}
╰╯
`

    conn.sendMessage(m.chat, {
        image: { url: 'https://files.catbox.moe/0fw4t2.jpg' },
        caption: txt
    }, { quoted: m })
}

handler.help = ['totalfitur']
handler.tags = ['info']
handler.command = ['totalfitur']

module.exports = handler
